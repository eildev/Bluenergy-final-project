    
<?php echo $__env->make('backend.body.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

        <!-- Begin page -->
        <div id="layout-wrapper">
            
            <?php echo $__env->make('backend.body.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

           <!-- Left Sidebar Start -->
            <?php echo $__env->make('backend.body.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

                
              <div class="main-content">
                <div class="page-content">
                    <?php echo $__env->yieldContent('admin'); ?>
                </div>
                
                <?php echo $__env->make('backend.body.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
            </div>
            <!-- end main content-->

        </div>

   <!-- JAVASCRIPT -->
   <?php echo $__env->make('backend.body.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php /**PATH D:\Kishor\BluEnergy\backend\resources\views/backend/admin_master.blade.php ENDPATH**/ ?>